//Character.cpp
#include "Character.h"

const int SKY_COLOR = makecol(8,6,45);

/**********************************************************************
*
*  Name:    Character
*
*  Author:  Ross Spencer 
*
*  Purpose: Constructor
*
**********************************************************************/
Character::Character()
{       
	x = 0;
	y = 0;

   upDone = SetImagesUp( "config\\up1.bmp", "config\\up2.bmp", "config\\up3.bmp");

   exploded = false;
}

/**********************************************************************
*
*  Name:    ~Character
*  
*  Author:  Ross Spencer 
*
*  Purpose: Destructor
*
**********************************************************************/
Character::~Character()
{
	delete [] images;
}

/**********************************************************************
*
*  Name:    SetSpeed
*
*  Author:  Ross Spencer 
*
*  Purpose: Set pigeon speed
*
**********************************************************************/
void Character::SetSpeed(int newspeed)
{
	speed = newspeed;
}

/**********************************************************************
*
*  Name:    SetImagesUp
*
*  Author:  Ross Spencer 
*
*  Purpose: Set pigeon images (redundancy here for moving wings if want)
*
**********************************************************************/
int Character::SetImagesUp(char image1[], char image2[], char image3[])
{
	images[0][0]= load_bitmap(image1, NULL);
	images[0][1]= load_bitmap(image2, NULL);
	images[0][2]= load_bitmap(image3, NULL);
   
   return true;
}

/**********************************************************************
*
*  Name:    CheckImages
*
*  Author:  Ross Spencer 
*
*  Purpose: Getter for successful load of images
*
**********************************************************************/
bool Character::CheckImages()
{
	return upDone;                         
}
 
/**********************************************************************
*
*  Name:    GetX
*
*  Author:  Ross Spencer 
*
*  Purpose: Get pigeon x
*
**********************************************************************/      
int Character::GetX()
{
	return x;
}

/**********************************************************************
*
*  Name:    GetY
*
*  Author:  Ross Spencer 
*
*  Purpose: Get pigeon y
*
**********************************************************************/       
int Character::GetY()
{
	return y;
}

/**********************************************************************
*
*  Name:    SetX
*
*  Author:  Ross Spencer 
*
*  Purpose: Set pigeon x
*
**********************************************************************/
void Character::SetX(int newValue)
{
	x = newValue;
}

/**********************************************************************
*
*  Name:    SetY
*
*  Author:  Ross Spencer 
*
*  Purpose: Set pigeon y
*
**********************************************************************/
void Character::SetY(int newValue)
{
	y = newValue;
}

/**********************************************************************
*
*  Name:    MoveOnY
*
*  Author:  Ross Spencer 
*
*  Purpose: Move pigeon along Y axis
*
**********************************************************************/
void Character::MoveOnY(BITMAP *buffer, BITMAP *screen)
{
	if(CheckImages())		// needs to go somewhere else, modify constructor maybe...
	{      
		//EraseOldSprite(buffer);

		if (y >= FINISH_LINE) 
		{    
			y -= speed;
		}
             
		//DrawNewSprite(buffer, images[0][0]);
	}
}

/**********************************************************************
*
*  Name:    
*
*  Author: Ross Spencer 
*
*  Purpose: 
*
**********************************************************************/
void Character::EraseOldSprite(BITMAP *buffer)
{
	acquire_screen();
	rectfill(buffer, GetX(), GetY(), GetX() + SPRITE_L_R, GetY() + SPRITE_L_R, SKY_COLOR);
	release_screen();
}

/**********************************************************************
*
*  Name:    
*
*  Author: Ross Spencer 
*
*  Purpose: 
*
**********************************************************************/
void Character::DrawNewSprite(BITMAP *buffer, BITMAP* sprite)
{
	acquire_screen();
	draw_sprite(buffer, images[0][0], GetX(), GetY());
	release_screen();
}

/**********************************************************************
*
*  Name:    
*
*  Author: Ross Spencer 
*
*  Purpose: 
*
**********************************************************************/
void Character::Show(BITMAP *screen, int x, int y)
{
	if(CheckImages())
	{
		draw_sprite(screen, images[0][0], x, y);
		SetX(x);
		SetY(y);
	}
}
