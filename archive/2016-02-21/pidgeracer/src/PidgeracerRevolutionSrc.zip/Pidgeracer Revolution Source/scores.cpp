#include "scores.h"

/**********************************************************************
*
*  Name:    ~Scores   
*
*  Author:  Ross Spencer    
*
*  Purpose: Output CSV containing scores on exit  
*
**********************************************************************/
Scores::~Scores()
{
   fstream new_file("config\\scores.csv", std::ios_base::out | std::ios_base::binary);

   score_row *temp_row;

   if(new_file.is_open())
   {
      for(int i = 0; i < score_rows.size(); i++)
      {
         temp_row = &score_rows.at(i);
         new_file << temp_row->name << "," << temp_row->wins << "," << temp_row->races << endl;
      }
   }

   new_file.close();
}

/**********************************************************************
*
*  Name:    make_actibe   
*
*  Author:  Ross Spencer    
*
*  Purpose: set member var to active...   
*
**********************************************************************/
void Scores::make_active(short pidge_index, int stat_index)
{
   score_rows.at(stat_index).index = pidge_index;
   score_rows.at(stat_index).active = true;
}

/**********************************************************************
*
*  Name:    add_new   
*
*  Author:  Ross Spencer    
*
*  Purpose: Add new row to vector   
*
**********************************************************************/
void Scores::add_new(score_row row_data)
{
   score_rows.push_back(row_data);
}

/**********************************************************************
*
*  Name:    update_stats   
*
*  Author:  Ross Spencer    
*
*  Purpose: Update the active pigeon statistics   
*
**********************************************************************/
void Scores::update_stats(short pidge_index)
{
   score_row *temp_row;

   for(int i = 0; i < score_rows.size(); i++)
   {
      temp_row = &score_rows.at(i);
      if(temp_row->active)
      {
         temp_row->races++;

         if(temp_row->index == pidge_index)
         {
            temp_row->wins++;
         }

         temp_row->percent = (temp_row->wins / temp_row->races) * 100;
      }
   }

   scores_sort();
}

/**********************************************************************
*
*  Name:    read_row_data   
*
*  Author:  Ross Spencer    
*
*  Purpose: Read data at given position   
*
**********************************************************************/
score_row Scores::read_row_data(int pos)
{
   return score_rows.at(pos);
}

/**********************************************************************
*
*  Name:    ReadScores   
*
*  Author:  Ross Spencer    
*
*  Purpose: Get row data from CSV and push into array. If we haven't
*           any data to get use default values  
*
**********************************************************************/
bool Scores::ReadScores()
{
   fstream score_file;
   score_file.open("config\\scores.csv", fstream::in);

   if(score_file.is_open())
   {
      score_row row;
      string line;
   
      int count = 0;
   
      while(getline (score_file, line))
      {
         istringstream linestream(line);
         string item;
         getline (linestream, item, ',');
         row.name = item;
         getline (linestream, item, ',');
   
         //NOTE: Getting to the depths of really crap code below, must fix at some point...
         //NOTE: Although, at least this currently works.
         //TODO: should probably be taken out of the loop (w/ time)
         stringstream test(item);
         test >> row.wins;
         getline (linestream, item, ',');
         //TODO: should probably be taken out of the loop (w/ time)
         stringstream test2(item);
         test2.str(item);
         test2 >> row.races;     
   
         row.active = false;
         row.percent = 0;
   
         score_rows.push_back(row);
      }
   
      score_file.close();

   }
   else
   {
      score_row row("Samurai Roadrunner",0,0);
      score_rows.push_back(row);
      row.name = "Cowabunga Guard";
      score_rows.push_back(row);
      row.name = "Mafia Jazz";
      score_rows.push_back(row);
      row.name = "Usagi Yojimbo";
      score_rows.push_back(row);
      row.name = "Tank Girl";
      score_rows.push_back(row);
      row.name = "Yamaha Mustang";
      score_rows.push_back(row);
      row.name = "Die Hard 4.0";
      score_rows.push_back(row);
      row.name = "Samurai Dynamite";
      score_rows.push_back(row);
      row.name = "Mustang Buzz";
      score_rows.push_back(row);
      row.name = "Cobra Girl";
      score_rows.push_back(row);
      row.name = "Blitzkrieg Blitz";
      score_rows.push_back(row);
      row.name = "Hitman Hart";
      score_rows.push_back(row);
   }

   score_row *temp_row;

   for(int i = 0; i < score_rows.size(); i++)
   {
      temp_row = &score_rows.at(i);
      if(!temp_row->wins)
      {
         temp_row->percent = 0;
      }
      else
      {
         temp_row->percent = (temp_row->wins / temp_row->races) * 100; 
      }
   }

   scores_sort();

   return 0;
}
