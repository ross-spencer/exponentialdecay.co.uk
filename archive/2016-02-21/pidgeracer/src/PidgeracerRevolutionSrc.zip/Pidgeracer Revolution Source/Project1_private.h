/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef PROJECT1_PRIVATE_H
#define PROJECT1_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.0.1.351"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	1
#define VER_BUILD	351
#define COMPANY_NAME	""
#define FILE_VERSION	""
#define FILE_DESCRIPTION	""
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"Pidgeracer Revolution"
#define PRODUCT_VERSION	"1.0"

#endif /*PROJECT1_PRIVATE_H*/
