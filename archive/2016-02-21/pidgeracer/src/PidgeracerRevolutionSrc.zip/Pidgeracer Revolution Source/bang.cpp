#include "bang.h"

/**********************************************************************
*
*  Name:    Bang
*
*  Author:  Ross Spencer 
*
*  Purpose: Constructor
*
**********************************************************************/
Bang::Bang()
{
   bangdone = SetImages("config\\bang.bmp");
   SetVector();
}

/**********************************************************************
*
*  Name:    ~Bang
*
*  Author:  Ross Spencer 
*
*  Purpose: Destructor
*
**********************************************************************/
Bang::~Bang()
{
   delete [] bang;
}

/**********************************************************************
*
*  Name:    SetImages
*
*  Author:  Ross Spencer 
*
*  Purpose: Load bang image
*
**********************************************************************/
bool Bang::SetImages(char image1[])
{
	bang[0][0] = load_bitmap(image1, NULL);
	return true;
}

/**********************************************************************
*
*  Name:    DrawBang 
*
*  Author:  Ross Spencer 
*
*  Purpose: Draw bang image to buffer at given x,y
*
**********************************************************************/
void Bang::DrawBang(BITMAP *buffer, int x, int y)
{
	acquire_screen();
   draw_sprite(buffer, bang[0][0], x, y);
	release_screen();
}

/**********************************************************************
*
*  Name:    SetVector
*
*  Author:  Ross Spencer 
*
*  Purpose: Set bang pair for shot gun effect - first = pigeon, 
*           second = position
*
**********************************************************************/
void Bang::SetVector()
{
   aim_vector.first = rng.GenerateRandom(0, 5);
   aim_vector.second = rng.GenerateRandom(FINISH_LINE+50 , FINISH_LINE+250);
}

/**********************************************************************
*
*  Name:    ResetBang
*
*  Author:  Ross Spencer 
*
*  Purpose: Reset shot gun pair
*
**********************************************************************/
std::pair <int,int> Bang::ResetBang()
{
   SetVector();
   return aim_vector;
}
