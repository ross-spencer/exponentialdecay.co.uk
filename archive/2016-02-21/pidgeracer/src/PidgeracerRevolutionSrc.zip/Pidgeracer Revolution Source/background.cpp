//background.cpp

#include "Background.h"

const int SKY_COLOR = makecol(8,6,45);

/**********************************************************************
*
*  Name:    Background
*
*  Author:  Ross Spencer
*
*  Purpose: Constructor()
*
**********************************************************************/
Background::Background()
{
	cloud = rn.GenerateBernoulli();
}

/**********************************************************************
*
*  Name:    DrawBackground
*
*  Author:  Ross Spencer
*
*  Purpose: Draw background to given buffer
*
**********************************************************************/
void Background::DrawBackground(BITMAP *buffer)
{
	acquire_screen();
	rect(buffer, SKY_BOUND_1_X, SKY_BOUND_1_Y, SKY_BOUND_2_X, SKY_BOUND_2_Y, makecol(255, 255, 255));
	rectfill(buffer, 60, 40, 640, 900, SKY_COLOR);
	release_screen();
}

/**********************************************************************
*
*  Name:    RedrawSky
*
*  Author:  Ross Spencer
*
*  Purpose: Given a bitmap redraw the sky after sprites have
*           moved over each position.
*
**********************************************************************/
void Background::RedrawSky(BITMAP *buffer)
{
	acquire_screen();
	rectfill(buffer, 60, 40, 640, 900, SKY_COLOR);
	release_screen();
}

/**********************************************************************
*
*  Name:    DrawStartLine
*
*  Author:  Ross Spencer
*
*  Purpose: Draw start line to screen
*
**********************************************************************/
void Background::DrawStartLine(BITMAP *buffer)
{
   acquire_screen();
	line(buffer, 60, 830, 640, 830, makecol(255, 255, 255));
	release_screen();
}

/**********************************************************************
*
*  Name:    EraseStartLine
*
*  Author:  Ross Spencer
*
*  Purpose: Erase start line when race has started
*
**********************************************************************/
void Background::EraseStartLine(BITMAP *buffer)
{
	acquire_screen();
	line(buffer, 60, 830, 640, 830, makecol(0, 0, 0));
	release_screen();
}

/**********************************************************************
*
*  Name:    DrawFinishLine
*
*  Author:  Ross Spencer
*
*  Purpose: Draw the finish line to bitmap when ready
*
**********************************************************************/
void Background::DrawFinishLine(BITMAP *buffer)
{
	acquire_screen();
	line(buffer, 60, 5+90, 640, 5+90, makecol(255, 255, 255));
	release_screen();
}

/**********************************************************************
*
*  Name:    EraseFinishLine
*
*  Author:  Ross Spencer
*
*  Purpose: EraseFinishLine if required
*
**********************************************************************/
void Background::EraseFinishLine(BITMAP *buffer)
{
	acquire_screen();
	line(buffer, 60, 5+90, 640, 5+90, makecol(0, 0, 0));
	release_screen();
}

/**********************************************************************
*
*  Name:    SetCloudImages
*
*  Author:  Ross Spencer
*
*  Purpose: Load clour images into array to draw onto sky
*
**********************************************************************/
void Background::SetCloudImages(char image1[], char image2[])
{
	clouds[0][0] = load_bitmap(image1, NULL);
	clouds[0][1] = load_bitmap(image2, NULL);
	cloudsDone = true;
}

/**********************************************************************
*
*  Name:    CheckImages
*
*  Author:  Ross Spencer
*
*  Purpose: Getter to see if images have loaded
*
**********************************************************************/
bool Background::CheckImages()
{
	return cloudsDone;
}

/**********************************************************************
*
*  Name:    GetX
*
*  Author:  Ross Spencer
*
*  Purpose: Get bg x pos
*
**********************************************************************/
int Background::GetX()
{
	return x;
}

/**********************************************************************
*
*  Name:    GetY
*
*  Author:  Ross Spencer
*
*  Purpose: Get bg y pos
*
**********************************************************************/
int Background::GetY()
{
	return y;
}

/**********************************************************************
*
*  Name:    SetX
*
*  Author:  Ross Spencer
*
*  Purpose: Set bg x pos
*
**********************************************************************/
void Background::SetX(int newValue)
{
	x = newValue;
}

/**********************************************************************
*
*  Name:    SetY
*
*  Author:  Ross Spencer
*
*  Purpose: Set bg y pos
*
**********************************************************************/
void Background::SetY(int newValue)
{
	y = newValue;
}

/**********************************************************************
*
*  Name:    MoveOnY
*
*  Author:  Ross Spencer
*
*  Purpose: Move clouds on the y axis during race simulation
*
**********************************************************************/
void Background::MoveOnY(BITMAP *buffer, BITMAP *screen)
{
	if(CheckImages())
	{      
		EraseOldSprite(buffer);
   
		if (y <= SKY_BOUND_2_Y - SPRITE_L_RR - 20) 
		{    
			y -= speed;
		}
		else
		{
			SetX(rn.GenerateRandom(SKY_BOUND_1_X + 4, SKY_BOUND_2_X - SPRITE_L_RR - 4));
			SetY(SKY_BOUND_1_Y + 4);
		}

		DrawNewSprite(buffer, clouds[0][cloud]);
	}
}

/**********************************************************************
*
*  Name:    EraseOldSprite
*
*  Author:  Ross Spencer
*
*  Purpose: Erase sprite from previous position
*
**********************************************************************/
void Background::EraseOldSprite(BITMAP *buffer)
{
	acquire_screen();
	rectfill(buffer, GetX(), GetY(), GetX() + SPRITE_L_RR, GetY() + SPRITE_L_RR, SKY_COLOR);
	release_screen();
}

/**********************************************************************
*
*  Name:    DrawNewSprite
*
*  Author:  Ross Spencer   
*
*  Purpose: Draw new sprite at new position
*
**********************************************************************/
void Background::DrawNewSprite(BITMAP *buffer, BITMAP* sprite)
{
	acquire_screen();
	draw_sprite(buffer, sprite, GetX(), GetY());
	release_screen();
}

/**********************************************************************
*
*  Name:    SetSpeed
*
*  Author:  Ross Spencer
*
*  Purpose: Set cloud speed?
*
**********************************************************************/
void Background::SetSpeed(int newspeed)
{
	speed = newspeed;
}

/**********************************************************************
*
*  Name:    Show
*
*  Author:  Ross Spencer
*
*  Purpose: Show clouds at given x,y pos when called
*
**********************************************************************/
void Background::Show(BITMAP *screen, int x, int y)
{
	if(CheckImages())
	{
		draw_sprite(screen, clouds[0][rn.GenerateBernoulli()], x, y);
		SetX(x);
		SetY(y);
	}
}

/**********************************************************************
*
*  Name:    Show
*
*  Author:  Ross Spencer
*
*  Purpose: Show clouds at member x,y when called
*
**********************************************************************/
void Background::Show(BITMAP *screen)
{
	if(CheckImages())
	{
		draw_sprite(screen, clouds[0][cloud], GetX(), GetY());
	}
}
